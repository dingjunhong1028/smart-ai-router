#!/bin/bash
# Simple health check script — can be called by cron or monitoring

SERVICES=("nginx" "pm2" "netdata")
FAILED=0

for svc in "${SERVICES[@]}"; do
  if ! systemctl is-active --quiet "$svc"; then
    echo "CRITICAL: $svc is down"
    FAILED=$((FAILED+1))
  fi
done

# PM2 process check
if ! pm2 list | grep -q "online"; then
  echo "CRITICAL: PM2 services not healthy"
  FAILED=$((FAILED+1))
fi

if [ $FAILED -gt 0 ]; then
  exit 2
fi
echo "OK - all services healthy"
